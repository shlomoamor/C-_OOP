﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.ConsoleUI
{
    
    public enum eMenuResults
    {
        AddVehicle = 1,
        DisplayAllLicenseNumbers = 2,
        ChangeVehicleState = 3,
        InflateWheels = 4,
        RefuelVehicle = 5,
        RechargeVehicle = 6,
        DisplayFullData = 7,
        Exit
    }
    
}
