﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public enum eCarColour
    {
        Red = 1,
        Blue = 2,
        Black = 3,
        Grey = 4
    }
}
