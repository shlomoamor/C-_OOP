﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Delegates
{
    public class Operation : Menu
    {
        public event Action ReportSelectedOperation;
        public Operation(string i_Title) : base(i_Title) { }

        internal override void ApplySubItem()
        {
            ReportSelectedOperation.Invoke();
            Console.Write("To go back press any key");
            Console.ReadLine();
        }
    }
}
