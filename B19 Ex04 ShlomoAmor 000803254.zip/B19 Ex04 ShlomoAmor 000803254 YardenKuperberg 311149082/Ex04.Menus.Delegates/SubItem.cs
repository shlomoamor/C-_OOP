﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Delegates
{
    public abstract class SubItem
    {
        
        protected internal string m_Title;
        protected readonly List<SubItem> r_SubItems;
        public SubItem (string i_Title)
        {
            r_SubItems = new List<SubItem>();
            m_Title = i_Title;
        }


        internal abstract void ApplySubItem();
    }
}