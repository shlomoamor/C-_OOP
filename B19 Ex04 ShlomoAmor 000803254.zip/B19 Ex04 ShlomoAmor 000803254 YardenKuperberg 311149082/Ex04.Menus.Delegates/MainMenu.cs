﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Delegates
{

    public class MainMenu : Menu
    {
        private class ExitItem : SubItem
        {
            public ExitItem() : base("0. Exit") { }

            internal override void ApplySubItem()
            {
            }
        }

        public MainMenu(string i_Title) : base(i_Title, new ExitItem()) { }

        public void OpenMenu()
        {
            ApplySubItem();
        }
    }
}