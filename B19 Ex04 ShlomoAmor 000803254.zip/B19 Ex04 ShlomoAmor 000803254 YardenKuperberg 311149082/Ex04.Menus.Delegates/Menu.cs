﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Delegates
{
    public class Menu : SubItem
    {
        private  int m_Index = 0;
        
        private SubItem m_Parent;

        public Menu(string i_Title) :base (i_Title)
        {
            m_Index = 1;
        }

        public Menu(string i_Title, SubItem i_SubItem) : base(i_Title) 
        {
            m_Index = 1;
            r_SubItems.Add(i_SubItem);
        }

        protected internal SubItem Parent
        {
            get { return m_Parent; }
            set
            {
                m_Parent = value;
                r_SubItems.Add(value);
            }
        }

        public void AddSubItem(SubItem i_SubItem)
        {
            r_SubItems.Add(i_SubItem);
            if (i_SubItem is Menu)
            {
                ((Menu)i_SubItem).Parent = this;
            }
            i_SubItem.m_Title = m_Index + ". " + i_SubItem.m_Title;
            m_Index++;
        }

        public void AddSubItems(List<SubItem> i_SubItems)
        {
            foreach (SubItem subItem in i_SubItems)
            {
                AddSubItem(subItem);
            }
        }

        internal override void ApplySubItem()
        {
            Console.Clear();
            showSubItems();
            int userChoiceIndex = receiveUserChoice();
            r_SubItems[userChoiceIndex].ApplySubItem();
            if (r_SubItems[userChoiceIndex] is Operation)
            {
                ApplySubItem();
            }
        }

        private void showSubItems()
        {
            StringBuilder menuOption = new StringBuilder();
            menuOption.AppendFormat("{0}{1}", m_Title, Environment.NewLine);
            menuOption.AppendFormat("=============={0}", Environment.NewLine);
            foreach (SubItem item in r_SubItems.Skip(1))
            {
                menuOption.AppendFormat("{0}{1}", item.m_Title, Environment.NewLine);
            }
            if (r_SubItems.ElementAt(0).m_Title != "0. Exit")
            {
                menuOption.Append("0. Back");
            }
            else
            {
                menuOption.Append( "0. Exit");
            }
            
            Console.WriteLine(menuOption.ToString());
        }

        private int receiveUserChoice()
        {
            int userChoiceIndex = 0;
            bool inputIsValid = false;
            Console.WriteLine(@"Please enter your choice(1-{0} or 0 to exit):", r_SubItems.Count - 1);
            Console.Write(">>");

            try
            {
                inputIsValid = int.TryParse(Console.ReadLine(), out userChoiceIndex);
                if (userChoiceIndex < 0 || userChoiceIndex > r_SubItems.Count())
                {
                    throw new IndexOutOfRangeException();
                }
            }
            catch (InvalidCastException e)
            {
                throw new InvalidCastException("Invalid option.", e);
            }
            return userChoiceIndex;
        }
        public bool IsValidOption(string i_InputOption, out int io_Option)
        {
            bool isValidOption = false;
            int option = 0;
            
            io_Option = option;
            return isValidOption;
        }
    }
}
