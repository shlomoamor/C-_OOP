﻿namespace Ex04.Menus.Interfaces
{
    public interface ISubItem
    {
        string Title
        {
            get;
        }
    }
}