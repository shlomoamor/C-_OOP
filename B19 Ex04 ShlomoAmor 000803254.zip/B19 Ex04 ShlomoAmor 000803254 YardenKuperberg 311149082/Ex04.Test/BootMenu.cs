﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ex04.Menus.Interfaces;
using Ex04.Menus.Delegates;
namespace Ex04.Test
 {
    public class BootMenu 
    {

        private Ex04.Menus.Interfaces.Menu creatInterfaceMenu()
        {
            Ex04.Menus.Interfaces.MainMenu interfaceMenu = new Menus.Interfaces.MainMenu("Interfrace Menu");

            Ex04.Menus.Interfaces.SubMenu subMenu1 = new Menus.Interfaces.SubMenu(interfaceMenu, "Show Date/Time");
            Ex04.Menus.Interfaces.SubMenu subMenu2 = new Menus.Interfaces.SubMenu(interfaceMenu, "Version and Digits");

            ShowTime subMenu1a = new ShowTime(subMenu1, "Show Time");
            ShowDate subMenu1b = new ShowDate(subMenu1, "Show Date");
            DisplayVersion subMenu2a = new DisplayVersion(subMenu2, "Display Version");
            CountingDigits subMenu2b = new CountingDigits(subMenu2, "Count Digits");

            return interfaceMenu;
        }

        private void runInterfaceMenu()
        {
            Ex04.Menus.Interfaces.Menu currentMenu = creatInterfaceMenu();
            int option = 0;
            while (currentMenu != null)
            {
                Console.Clear();
                Console.Write(currentMenu.ToString());
                string input = Console.ReadLine();
                currentMenu.IsValidOption(input, out option);
                if (option == 0)
                {
                    currentMenu = currentMenu.PrevMenu();
                }
                else if (currentMenu.isSubMenu(option))
                {
                    currentMenu = currentMenu.GetSubMenu(option);
                }
                else
                {
                    currentMenu.Operate(option);
                    Console.Write("To go back press any key");
                    Console.ReadLine();
                }
            }
        }

        private Ex04.Menus.Delegates.MainMenu createDelegateMenu()
        {
            Ex04.Menus.Delegates.MainMenu mainMenu = new Menus.Delegates.MainMenu("Delegates menu");
            Ex04.Menus.Delegates.Menu subMenu1 = new Menus.Delegates.Menu("Show Date/Time");
            Ex04.Menus.Delegates.Menu subMenu2 = new Menus.Delegates.Menu("Version and Digits");

            Ex04.Menus.Delegates.Operation subMenu1a = new Menus.Delegates.Operation("Show Time");
            Ex04.Menus.Delegates.Operation subMenu1b = new Menus.Delegates.Operation("Show Date");

            Ex04.Menus.Delegates.Operation subMenu2a = new Menus.Delegates.Operation("Count Digits");
            Ex04.Menus.Delegates.Operation subMenu2b = new Menus.Delegates.Operation("Display Version");
            DelegateMethods delegateMethods = new DelegateMethods();

            mainMenu.AddSubItem(subMenu1);
            mainMenu.AddSubItem(subMenu2);
            subMenu1a.ReportSelectedOperation += delegateMethods.ShowDate;
            subMenu1.AddSubItem(subMenu1a);
            subMenu1b.ReportSelectedOperation += delegateMethods.ShowTime;
            subMenu1.AddSubItem(subMenu1b);
            subMenu2a.ReportSelectedOperation += delegateMethods.CountDigitsOperation;
            subMenu2.AddSubItem(subMenu2a);
            subMenu2b.ReportSelectedOperation += delegateMethods.DisplayVersion;
            subMenu2.AddSubItem(subMenu2b);

            return mainMenu;
        }

        private void runDelegatesMenu()
        {
            Ex04.Menus.Delegates.MainMenu mainMenu = createDelegateMenu();
            mainMenu.OpenMenu();
        }

        public void Run()
        {
            runInterfaceMenu();
            runDelegatesMenu();
            
        }
  
    }
}