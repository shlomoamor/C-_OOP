﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Test
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BootMenu newMenu = new BootMenu();
            newMenu.Run();
        }
        
    }
}
