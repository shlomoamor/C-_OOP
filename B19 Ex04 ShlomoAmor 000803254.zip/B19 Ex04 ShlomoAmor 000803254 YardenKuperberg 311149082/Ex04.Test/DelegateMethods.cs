﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ex04.Test
{
    public class DelegateMethods
    {

        public void ShowDate()
        {
            Console.Clear();
            Console.WriteLine(DateTime.Today.ToString("d"));
        }

        public  void ShowTime()
        {
            Console.Clear();
            Console.WriteLine(DateTime.Now.ToString("HH:mm:ss"));
        }

        public  void CountDigitsOperation()
        {
            Console.Clear();
            CountDigits();
        }

        public  void DisplayVersion()
        {
            Console.Clear();
            Console.WriteLine("App Version 19.2.4.32");
        }

        internal void CountDigits()
        {
            Console.Clear();
            string inputSentence = "";
            int numberOfDigits = 0;

            Console.WriteLine("Please enter a sentence");
            inputSentence = Console.ReadLine();
            foreach (char currLetterInSentence in inputSentence)
            {
                if (char.IsDigit(currLetterInSentence))
                {
                    numberOfDigits++;
                }
            }

            Console.WriteLine(string.Format("You have {0} number of digits in the inputted sentence.", numberOfDigits));
        }
    }
}
